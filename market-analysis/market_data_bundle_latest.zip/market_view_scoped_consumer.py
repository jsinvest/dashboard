"""Use only verified domestic prices, preserving the producer's WARN verbatim.
One-off user-authorized 20261012 Nikkei holiday exclusion; no producer/code changes.
"""
import importlib.util,json,hashlib,sys
from pathlib import Path
R=Path(r'C:\Users\skylo\Documents\New project');B=Path(r'C:\Users\skylo\Desktop\trading_strength')
spec=importlib.util.spec_from_file_location('view_hit_rate',R/'scripts/update_market_view_hit_rate.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
original=m.find_verified_index_bundle
def scoped(root,requested):
 if requested!='20261012':return original(root,requested)
 folder=root/requested;v=m.read_json(folder/f'validation_{requested}.json')
 assert v['trade_date']==requested and v['can_use_for_decision'] is True
 assert all(v['instruments'][x]['status']=='OK' and v['instruments'][x]['can_use_for_decision'] is True for x in ['KOSPI','KOSDAQ'])
 manifest=m.read_json(folder/f'manifest_{requested}.json')
 for x in manifest['files']:assert hashlib.sha256((folder/x['path']).read_bytes()).hexdigest()==x['sha256']
 # Return the original validation including WARN, not a forged OK.
 return folder,v
m.find_verified_index_bundle=scoped
sys.argv=['update_market_view_hit_rate.py','--price-date','20261012','--index-root',str(B/'output/index_multitimeframe')]
raise SystemExit(m.main())
