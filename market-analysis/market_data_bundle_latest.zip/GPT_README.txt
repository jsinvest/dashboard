11/11 저녁 최종: manifest 해시, analysis_latest, validation/mandatory_audit, 후보87개 원자료와 차트 순으로 확인. 장중원천·저녁지수·장후브로커종목의 시각을 구분. 독립거래소 종목종가 인증 아님.14단계 연구층 제외. 추천0·조건부관심3. 인증·계좌정보 없음.
