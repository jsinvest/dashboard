# 미국 지수 보조 분석 · 한국 20261013 / 미국 완료장 2026-10-12

Yahoo 지연 보조 원천이며 공식 가격 독립 검증은 아닙니다.

## 나스닥종합

종가 27245.9 · 1/5/20일 {'1': -0.439, '5': -0.842, '20': 4.046, '60': 6.762} · 일봉 상승 · RSI 57.387

이평 {'sma5': 27388.778, 'sma10': 27214.226, 'sma20': 26958.699, 'sma60': 26365.311, 'sma120': 26145.653, 'sma240': 24586.376}

가격 비교 {'previous_20_high': 27722.75, 'previous_20_low': 25802.961, 'previous_60_high': 27722.75, 'previous_60_low': 24425.34}

## 필라델피아 반도체

종가 12236.79 · 1/5/20일 {'1': -2.67, '5': -7.105, '20': 9.932, '60': 4.822} · 일봉 상승 · RSI 46.786

이평 {'sma5': 12743.378, 'sma10': 12811.308, 'sma20': 12466.995, 'sma60': 12009.324, 'sma120': 12178.216, 'sma240': 9926.884}

가격 비교 {'previous_20_high': 13349.96, 'previous_20_low': 11110.11, 'previous_60_high': 13349.96, 'previous_60_low': 10445.44}

## 다우 산업평균

종가 51850.551 · 1/5/20일 {'1': 0.379, '5': 1.136, '20': -1.089, '60': -0.567} · 일봉 하락 · RSI 50.634

이평 {'sma5': 51487.659, 'sma10': 51306.568, 'sma20': 51508.28, 'sma60': 52537.138, 'sma120': 51715.239, 'sma240': 49894.821}

가격 비교 {'previous_20_high': 52750.879, 'previous_20_low': 50546.539, 'previous_60_high': 54744.328, 'previous_60_low': 50546.539}

## 니케이225

종가 67777.523 · 1/5/20일 {'1': -1.816, '5': -3.101, '20': 4.045, '60': 0.795} · 일봉 상승 · RSI 53.156

이평 {'sma5': 69314.048, 'sma10': 68601.827, 'sma20': 66655.583, 'sma60': 66051.153, 'sma120': 65552.341, 'sma240': 59072.103}

가격 비교 {'previous_20_high': 70798.617, 'previous_20_low': 62726.18, 'previous_60_high': 70798.617, 'previous_60_low': 60448.898}

## 국내 연결

{
  "kospi": {
    "close": 6035.35,
    "return_pct": -5.464863476310411,
    "opening_gap_pct": -3.103893337343211,
    "open_to_close_pct": -2.436599591340549,
    "us_leading_relationships": {
      "NASDAQ": {
        "20": {
          "observations": 20,
          "distinct_us_sessions": 20,
          "correlation": 0.15409523778393913,
          "direction_match_pct": 70.0
        },
        "60": {
          "observations": 60,
          "distinct_us_sessions": 59,
          "correlation": 0.39482018187350365,
          "direction_match_pct": 61.66666666666667
        },
        "120": {
          "observations": 120,
          "distinct_us_sessions": 117,
          "correlation": 0.3817586287403779,
          "direction_match_pct": 63.33333333333333
        }
      },
      "SOX": {
        "20": {
          "observations": 20,
          "distinct_us_sessions": 20,
          "correlation": 0.4286423936757097,
          "direction_match_pct": 60.0
        },
        "60": {
          "observations": 60,
          "distinct_us_sessions": 59,
          "correlation": 0.5374787894860602,
          "direction_match_pct": 68.33333333333333
        },
        "120": {
          "observations": 120,
          "distinct_us_sessions": 117,
          "correlation": 0.41000154191683397,
          "direction_match_pct": 65.0
        }
      },
      "DOW": {
        "20": {
          "observations": 20,
          "distinct_us_sessions": 20,
          "correlation": -0.4079517625469193,
          "direction_match_pct": 50.0
        },
        "60": {
          "observations": 60,
          "distinct_us_sessions": 59,
          "correlation": 0.06676897723226481,
          "direction_match_pct": 51.66666666666667
        },
        "120": {
          "observations": 120,
          "distinct_us_sessions": 117,
          "correlation": 0.12152476004733853,
          "direction_match_pct": 50.83333333333333
        }
      }
    }
  },
  "kosdaq": {
    "close": 837.03,
    "return_pct": -1.4319528020819927,
    "opening_gap_pct": -3.002861550418634,
    "open_to_close_pct": 1.6195413322973362,
    "us_leading_relationships": {
      "NASDAQ": {
        "20": {
          "observations": 20,
          "distinct_us_sessions": 20,
          "correlation": 0.007045375286357606,
          "direction_match_pct": 45.0
        },
        "60": {
          "observations": 60,
          "distinct_us_sessions": 59,
          "correlation": 0.5097866573026217,
          "direction_match_pct": 58.333333333333336
        },
        "120": {
          "observations": 120,
          "distinct_us_sessions": 117,
          "correlation": 0.37466484243457393,
          "direction_match_pct": 55.00000000000001
        }
      },
      "SOX": {
        "20": {
          "observations": 20,
          "distinct_us_sessions": 20,
          "correlation": 0.14223057154944893,
          "direction_match_pct": 65.0
        },
        "60": {
          "observations": 60,
          "distinct_us_sessions": 59,
          "correlation": 0.44124068039213515,
          "direction_match_pct": 65.0
        },
        "120": {
          "observations": 120,
          "distinct_us_sessions": 117,
          "correlation": 0.29915159338980385,
          "direction_match_pct": 60.0
        }
      },
      "DOW": {
        "20": {
          "observations": 20,
          "distinct_us_sessions": 20,
          "correlation": -0.4682923577130371,
          "direction_match_pct": 25.0
        },
        "60": {
          "observations": 60,
          "distinct_us_sessions": 59,
          "correlation": 0.24636732731025526,
          "direction_match_pct": 51.66666666666667
        },
        "120": {
          "observations": 120,
          "distinct_us_sessions": 117,
          "correlation": 0.11980549731619482,
          "direction_match_pct": 44.166666666666664
        }
      }
    }
  }
}

## 한계

거래소 공식 가격 독립 검증 아님
미국 현물과 선물은 별도 상품
월·주 진행봉은 점수에서 제외
나스닥·SOX 중복 요인을 독립 점수로 더하지 않음
정확한 코스피 상승 기여도는 직전 종목 비중이 없으면 산출하지 않음
휴장으로 같은 미국 세션이 여러 한국 거래일에 연결될 수 있어 관측수와 고유 미국 세션수를 분리함. 상관·일치율은 검증된 예측 승률이 아님