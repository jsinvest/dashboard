# 미국 지수 보조 분석 · 한국 20261014 / 미국 완료장 2026-10-13

Yahoo 지연 보조 원천이며 공식 가격 독립 검증은 아닙니다.

## 나스닥종합

종가 27204.381 · 1/5/20일 {'1': -0.152, '5': -1.433, '20': 4.706, '60': 6.65} · 일봉 상승 · RSI 56.389

이평 {'sma5': 27309.696, 'sma10': 27254.91, 'sma20': 27019.839, 'sma60': 26393.583, 'sma120': 26166.877, 'sma240': 24600.447}

가격 비교 {'previous_20_high': 27722.75, 'previous_20_low': 25802.961, 'previous_60_high': 27722.75, 'previous_60_low': 24425.34}

## 필라델피아 반도체

종가 12208.79 · 1/5/20일 {'1': -0.229, '5': -7.634, '20': 9.246, '60': 3.959} · 일봉 상승 · RSI 46.303

이평 {'sma5': 12541.572, 'sma10': 12769.271, 'sma20': 12518.657, 'sma60': 12017.073, 'sma120': 12197.379, 'sma240': 9947.776}

가격 비교 {'previous_20_high': 13349.96, 'previous_20_low': 11128.88, 'previous_60_high': 13349.96, 'previous_60_low': 10445.44}

## 다우 산업평균

종가 51670.102 · 1/5/20일 {'1': -0.348, '5': 0.289, '20': -0.812, '60': -0.326} · 일봉 하락 · RSI 48.174

이평 {'sma5': 51517.423, 'sma10': 51338.586, 'sma20': 51487.129, 'sma60': 52534.318, 'sma120': 51733.406, 'sma240': 49911.336}

가격 비교 {'previous_20_high': 52336.609, 'previous_20_low': 50546.539, 'previous_60_high': 54744.328, 'previous_60_low': 50546.539}

## 니케이225

종가 67744.289 · 1/5/20일 {'1': -0.049, '5': -4.159, '20': 3.789, '60': 0.001} · 일봉 상승 · RSI 52.988

이평 {'sma5': 68726.111, 'sma10': 68828.129, 'sma20': 66779.25, 'sma60': 66051.166, 'sma120': 65632.425, 'sma240': 59153.214}

가격 비교 {'previous_20_high': 70798.617, 'previous_20_low': 62726.18, 'previous_60_high': 70798.617, 'previous_60_low': 60448.898}

## 국내 연결

{
  "kospi": {
    "close": 6008.81,
    "return_pct": -0.4397425170039826,
    "opening_gap_pct": 0.4428906360028684,
    "open_to_close_pct": -0.8787412901182345,
    "us_leading_relationships": {
      "NASDAQ": {
        "20": {
          "observations": 20,
          "distinct_us_sessions": 20,
          "correlation": 0.16780809741111039,
          "direction_match_pct": 70.0
        },
        "60": {
          "observations": 60,
          "distinct_us_sessions": 59,
          "correlation": 0.4101315134591545,
          "direction_match_pct": 63.33333333333333
        },
        "120": {
          "observations": 120,
          "distinct_us_sessions": 117,
          "correlation": 0.37965633029711776,
          "direction_match_pct": 63.33333333333333
        }
      },
      "SOX": {
        "20": {
          "observations": 20,
          "distinct_us_sessions": 20,
          "correlation": 0.42625865022235326,
          "direction_match_pct": 65.0
        },
        "60": {
          "observations": 60,
          "distinct_us_sessions": 59,
          "correlation": 0.5590414098048395,
          "direction_match_pct": 70.0
        },
        "120": {
          "observations": 120,
          "distinct_us_sessions": 117,
          "correlation": 0.40884777284305684,
          "direction_match_pct": 65.0
        }
      },
      "DOW": {
        "20": {
          "observations": 20,
          "distinct_us_sessions": 20,
          "correlation": -0.40843582860218125,
          "direction_match_pct": 50.0
        },
        "60": {
          "observations": 60,
          "distinct_us_sessions": 59,
          "correlation": 0.0684999556750667,
          "direction_match_pct": 53.333333333333336
        },
        "120": {
          "observations": 120,
          "distinct_us_sessions": 117,
          "correlation": 0.11907601878236469,
          "direction_match_pct": 50.83333333333333
        }
      }
    }
  },
  "kosdaq": {
    "close": 823.88,
    "return_pct": -1.5710309068969974,
    "opening_gap_pct": -0.13500113496529575,
    "open_to_close_pct": -1.4379710491685627,
    "us_leading_relationships": {
      "NASDAQ": {
        "20": {
          "observations": 20,
          "distinct_us_sessions": 20,
          "correlation": 0.04910055377784282,
          "direction_match_pct": 50.0
        },
        "60": {
          "observations": 60,
          "distinct_us_sessions": 59,
          "correlation": 0.5064105779620889,
          "direction_match_pct": 58.333333333333336
        },
        "120": {
          "observations": 120,
          "distinct_us_sessions": 117,
          "correlation": 0.3686266195293075,
          "direction_match_pct": 55.00000000000001
        }
      },
      "SOX": {
        "20": {
          "observations": 20,
          "distinct_us_sessions": 20,
          "correlation": 0.14890178655100017,
          "direction_match_pct": 65.0
        },
        "60": {
          "observations": 60,
          "distinct_us_sessions": 59,
          "correlation": 0.43561162429990036,
          "direction_match_pct": 65.0
        },
        "120": {
          "observations": 120,
          "distinct_us_sessions": 117,
          "correlation": 0.2969820666825366,
          "direction_match_pct": 60.0
        }
      },
      "DOW": {
        "20": {
          "observations": 20,
          "distinct_us_sessions": 20,
          "correlation": -0.4327579274230712,
          "direction_match_pct": 30.0
        },
        "60": {
          "observations": 60,
          "distinct_us_sessions": 59,
          "correlation": 0.2468534051693939,
          "direction_match_pct": 51.66666666666667
        },
        "120": {
          "observations": 120,
          "distinct_us_sessions": 117,
          "correlation": 0.11622713740163816,
          "direction_match_pct": 44.166666666666664
        }
      }
    }
  }
}

## 한계

거래소 공식 가격 독립 검증 아님
미국 현물과 선물은 별도 상품
월·주 진행봉은 점수에서 제외
나스닥·SOX 중복 요인을 독립 점수로 더하지 않음
정확한 코스피 상승 기여도는 직전 종목 비중이 없으면 산출하지 않음
휴장으로 같은 미국 세션이 여러 한국 거래일에 연결될 수 있어 관측수와 고유 미국 세션수를 분리함. 상관·일치율은 검증된 예측 승률이 아님