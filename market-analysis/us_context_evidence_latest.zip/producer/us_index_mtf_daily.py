"""US cash-index charts and point-in-time Korean market context. No orders/UI/upload.

Yahoo is a delayed secondary source. Data checks are not independent official-price
certification. Current monthly/weekly candles are displayed but not scored.
"""
from __future__ import annotations
import argparse
import json
import time as clock
import urllib.request
from functools import lru_cache
from datetime import date, datetime, time, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo
import numpy as np
import pandas as pd
from pandas.tseries.holiday import (AbstractHolidayCalendar, Holiday, nearest_workday,
    USMartinLutherKingJr, USPresidentsDay, USMemorialDay, USLaborDay, USThanksgivingDay, GoodFriday)
from kospi_nikkei_mtf_daily import (Instrument, yahoo_chart_url, daily_by_local_date,
    resample_ohlcv, add_indicators, timeframe_analysis, TIMEFRAME_CONFIG,
    plot_candles, plt, write_json, sha256_file, USER_AGENT)

BASE=Path(__file__).resolve().parent
NY=ZoneInfo('America/New_York'); KST=ZoneInfo('Asia/Seoul')
INDICES={k:Instrument(k,n,s,'America/New_York',time(9,30),time(16)) for k,n,s in [
    ('NASDAQ','나스닥종합','^IXIC'),('SOX','필라델피아 반도체','^SOX'),('DOW','다우 산업평균','^DJI')]}
TF_ORDER=('monthly','weekly','daily','intraday_10m')
def config(tf):
    return TIMEFRAME_CONFIG['intraday_15m' if tf=='intraday_10m' else tf]

def new_year_observed(d):
    # NYSE does not move a Saturday New Year's Day to the preceding Friday.
    return d+pd.Timedelta(days=1) if d.weekday()==6 else d

class CashCalendar(AbstractHolidayCalendar):
    rules=[Holiday('New Year',month=1,day=1,observance=new_year_observed),
        USMartinLutherKingJr,USPresidentsDay,GoodFriday,USMemorialDay,
        Holiday('Juneteenth',month=6,day=19,start_date='2022-01-01',observance=nearest_workday),
        Holiday('Independence',month=7,day=4,observance=nearest_workday),USLaborDay,
        USThanksgivingDay,Holiday('Christmas',month=12,day=25,observance=nearest_workday)]

SPECIAL_CLOSURES={date(2018,12,5),date(2025,1,9)}
def sessions(start,end):
    holidays=set(CashCalendar().holidays(start,end).date)|SPECIAL_CLOSURES
    return [x.date() for x in pd.date_range(start,end,freq='B') if x.date() not in holidays]

@lru_cache(maxsize=20000)
def close_time(day):
    first=date(day.year,11,1)
    friday_after_thanksgiving=first+timedelta(days=(3-first.weekday())%7+22)
    early=(day==friday_after_thanksgiving or (day.month==12 and day.day==24) or
           (day.month==7 and day.day==3) or (day.month==7 and day.day==2 and date(day.year,7,4).weekday()==5))
    return datetime.combine(day,time(13) if early else time(16),NY)

def expected_session(cutoff):
    days=sessions(cutoff.date()-timedelta(days=15),cutoff.date())
    completed=[d for d in days if close_time(d)<=cutoff]
    if not completed: raise ValueError('No completed US session')
    return completed[-1]

def fetch(instrument,interval,us_day,raw_path):
    start=datetime.combine(us_day-timedelta(days=12*366 if interval=='1d' else 30),time.min,NY)
    end=datetime.combine(us_day+timedelta(days=1),time.min,NY)
    url=yahoo_chart_url(instrument,interval,start,end)
    for attempt in range(3):
        try:
            request=urllib.request.Request(url,headers={'User-Agent':USER_AGENT})
            with urllib.request.urlopen(request,timeout=25) as r: raw=r.read()
            break
        except Exception:
            if attempt==2: raise
            clock.sleep(1+attempt)
    raw_path.parent.mkdir(parents=True,exist_ok=True);raw_path.write_bytes(raw)
    body=json.loads(raw)['chart']
    if body.get('error'): raise ValueError(str(body['error']))
    result=body['result'][0]; q=result['indicators']['quote'][0]; stamps=result.get('timestamp',[])
    if not stamps or any(len(q.get(c,[]))!=len(stamps) for c in ['open','high','low','close','volume']):
        raise ValueError('Empty or mismatched source arrays')
    if result['meta'].get('exchangeTimezoneName')!='America/New_York':raise ValueError('Wrong source timezone')
    df=pd.DataFrame({c:q[c] for c in ['open','high','low','close','volume']},index=pd.to_datetime(stamps,unit='s',utc=True).tz_convert(NY)).astype(float)
    df=df[df.index.date<=us_day].sort_index()
    duplicate=int(df.index.duplicated().sum())
    for _,g in df[df.index.duplicated(False)].groupby(level=0):
        if len(g.drop_duplicates())>1:raise ValueError('Conflicting duplicate timestamps')
    df=df[~df.index.duplicated()]
    empty=df[['open','high','low','close']].isna().all(axis=1); empty_count=int(empty.sum());df=df[~empty]
    if df[['open','high','low','close']].isna().any().any():raise ValueError('Partial missing OHLC')
    bad=(df.high<df[['open','close','low']].max(axis=1))|(df.low>df[['open','close','high']].min(axis=1))|(df[['open','high','low','close']]<=0).any(axis=1)
    if bad.any():raise ValueError('Invalid OHLC relationship')
    volume_missing=int(df.volume.isna().sum())
    # Index volumes are source-specific, not used as traded volume or flow signals.
    if interval=='5m':
        df=df[(df.index.time>=time(9,30)) & (df.index.time<=time(16))]
    if df.empty or df.index[-1].date()!=us_day:raise ValueError('Latest US session missing')
    audit={'source':'Yahoo chart API delayed secondary','url':url,'timezone':'America/New_York',
        'raw_sha256':sha256_file(raw_path),'identical_duplicates_removed':duplicate,
        'empty_placeholder_rows_removed':empty_count,'missing_volume_rows':volume_missing,
        'ohlc_missing':0,'invalid_ohlc':0,'rows':len(df),'latest':df.index[-1].isoformat(),
        'independent_official_price_crosscheck':False}
    return df,audit

def intraday_bars(df,us_day):
    pieces=[];gaps=[]
    for day,g in df.groupby(df.index.date):
        if day not in sessions(day,day):raise ValueError(f'Bars on closed session {day}')
        end=close_time(day);g=g[g.index<=end]
        expected=pd.date_range(datetime.combine(day,time(9,30),NY),end,freq='5min',inclusive='left')
        missing=expected.difference(g.index)
        if len(missing):gaps.append({'date':str(day),'missing_5m_count':len(missing)})
        # The terminal 16:00/13:00 print belongs to the last regular 10-minute candle.
        h=g.copy();h.index=pd.DatetimeIndex([t-pd.Timedelta(microseconds=1) if t==end else t for t in h.index])
        pieces.append(resample_ohlcv(h,'10min'))
    out=pd.concat(pieces).sort_index() if pieces else pd.DataFrame()
    if out.empty:raise ValueError('No intraday bars')
    return out,gaps

def closed_period(frame,key,us_day):
    if key not in ('weekly','monthly'):return frame,False
    p=pd.Timestamp(us_day).to_period('W-FRI' if key=='weekly' else 'M')
    period_end=p.end_time.date();last=sessions(p.start_time.date(),period_end)[-1]
    partial=us_day<last
    return (frame.iloc[:-1] if partial else frame),partial

def linked_history(us_daily,kr_daily):
    left=pd.DataFrame({'kr_date':kr_daily.index,'kr_return':kr_daily.close.pct_change()*100})
    left['cutoff']=pd.to_datetime([datetime.combine(d.date(),time(9),KST) for d in left.kr_date],utc=True)
    right=pd.DataFrame({'us_date':us_daily.index,'us_return':us_daily.close.pct_change()*100})
    right['cutoff']=pd.to_datetime([close_time(d.date()) for d in right.us_date],utc=True)
    joined=pd.merge_asof(left.sort_values('cutoff'),right.sort_values('cutoff'),on='cutoff',direction='backward',tolerance=pd.Timedelta(days=7)).dropna()
    joined=joined[joined.us_date.dt.date<joined.kr_date.dt.date]
    return joined

def japan_10m(df):
    pieces=[];gaps=[]
    for day,g in df.groupby(df.index.date):
        for begin,end in [(time(9),time(11,30)),(time(12,30),time(15,30))]:
            start=pd.Timestamp(datetime.combine(day,begin,ZoneInfo('Asia/Tokyo')))
            finish=pd.Timestamp(datetime.combine(day,end,ZoneInfo('Asia/Tokyo')))
            segment=g[(g.index>=start)&(g.index<=finish)].copy()
            expected=pd.date_range(start,finish,freq='5min',inclusive='left')
            missing=expected.difference(segment.index)
            if len(missing):gaps.append({'date':str(day),'session':str(begin),'missing_5m_count':len(missing),
                                         'missing_timestamps':[t.isoformat() for t in missing]})
            segment.index=pd.DatetimeIndex([t-pd.Timedelta(microseconds=1) if t==finish else t for t in segment.index])
            if not segment.empty:pieces.append(resample_ohlcv(segment,'10min'))
    return pd.concat(pieces).sort_index(),gaps

def validated_japan_window(df,target):
    """Score only the complete, uninterrupted suffix; retain every source-gap record.

    Never fill a missing candle or join history across a bad session. Daily and
    higher-timeframe history stays separate from this intraday indicator window.
    """
    bars,source_gaps=japan_10m(df)
    last_bad=max((date.fromisoformat(g['date']) for g in source_gaps),default=None)
    active=df[df.index.date>last_bad] if last_bad else df
    if active.empty:raise ValueError('Nikkei latest session has a source gap; no valid suffix')
    bars,active_gaps=japan_10m(active)
    required=max(config('intraday_10m')['ma_periods'])+20
    if active_gaps or bars.index[-1].date()!=target:
        raise ValueError('Nikkei active 10m window has a gap or stale last session')
    if len(bars)<required or len(set(active.index.date))<5:
        raise ValueError(f'Nikkei complete suffix too short: {len(bars)} bars; need {required} and 5 sessions')
    audit={'start':bars.index[0].isoformat(),'end':bars.index[-1].isoformat(),
           'complete_sessions':len(set(active.index.date)),'bars_10m':len(bars),
           'minimum_bars':required,'gap_excluded_through':str(last_bad) if last_bad else None,
           'source_gap_recovered':False if source_gaps else None,'filled_bars':0,
           'policy':'Only complete sessions after the last source-gap day; indicators restart in this window'}
    return bars,source_gaps,audit

def export_frames(key,name,base,detail,session_day,day,out,japan=False):
    analyses={};enriched={}
    for tf,frame in base.items():
        conf=config(tf);enriched[tf]=add_indicators(frame,conf['ma_kind'],conf['ma_periods'])
        score_frame,partial=closed_period(enriched[tf],tf,session_day)
        if japan and tf in ('monthly','weekly'):
            period=pd.Timestamp(session_day).to_period('M' if tf=='monthly' else 'W-FRI')
            partial=session_day<period.end_time.date()
            score_frame=enriched[tf].iloc[:-1] if partial else enriched[tf]
        analyses[tf]=timeframe_analysis(score_frame,'intraday_15m' if tf=='intraday_10m' else tf,'complete')
        analyses[tf].update(display_bar_is_partial=partial,can_use=tf!='intraday_10m' or detail['intraday_can_use'])
        enriched[tf].to_csv(out/f'{key}_{tf}.csv',index_label='timestamp')
    chart=out/f'{key}_mtf.png';fig,axes=plt.subplots(2,2,figsize=(15,10),constrained_layout=True)
    for ax,tf in zip(axes.flat,TF_ORDER):
        if tf not in enriched:ax.text(.1,.5,'분봉 원천 없음');continue
        label='10분봉' if tf=='intraday_10m' else config(tf)['label']
        title=f"{label} · {analyses[tf]['state']}"
        plot_candles(ax,enriched[tf],config(tf),title)
        notes=[]
        if analyses[tf]['display_bar_is_partial']:notes.append('진행봉 표시 / 점수 제외')
        if not analyses[tf]['can_use']:notes.append('원천갭 / 판단 제외')
        if notes:ax.text(.98,.98,' · '.join(notes),transform=ax.transAxes,ha='right',va='top',fontsize=8,bbox={'facecolor':'white','alpha':.8,'edgecolor':'none'})
    fig.suptitle(f'{name} · 현물 세션 {session_day} · 한국 기준 {day} · Yahoo 지연 보조')
    fig.savefig(chart,dpi=120);plt.close(fig)
    return {'name':name,'source_session_date':str(session_day),'timeframes':analyses,'chart':str(chart),'daily_csv':str(out/f'{key}_daily.csv')}

def add_nikkei(day,out,domestic_root=None):
    source=(domestic_root or BASE/'output/index_multitimeframe')/day;target=datetime.strptime(day,'%Y%m%d').date()
    valpath=source/f'validation_{day}.json';v=json.loads(valpath.read_text(encoding='utf-8-sig'))
    if v.get('trade_date')!=day or not v['instruments']['NIKKEI225'].get('can_use_for_decision'):raise ValueError('Nikkei upstream validation failed')
    manifest=json.loads((source/f'manifest_{day}.json').read_text(encoding='utf-8-sig'))
    declared={x['path']:x['sha256'] for x in manifest['files']}
    frames={};hashes={}
    for key in ['daily','5m']:
        rel=f'data/nikkei225_{key}_{day}.csv';p=source/rel
        if declared.get(rel)!=sha256_file(p):raise ValueError(f'Nikkei input hash mismatch {key}')
        f=pd.read_csv(p,index_col=0,parse_dates=True)
        if f.index.duplicated().any() or f[['open','high','low','close']].isna().any().any():raise ValueError('Nikkei duplicate/missing OHLC')
        if f.index[-1].date()!=target:raise ValueError('Nikkei stale input')
        frames[key]=f;hashes[str(p)]=sha256_file(p)
    bars,gaps,window=validated_japan_window(frames['5m'],target);daily=frames['daily']
    expected_days={d for d in daily.index.date if bars.index[0].date()<=d<=target}
    if expected_days!=set(bars.index.date):
        raise ValueError('Nikkei complete daily sessions missing from active intraday window')
    window['daily_session_crosscheck']='MATCH'
    gap=abs(bars.close.iloc[-1]/daily.close.iloc[-1]-1)*100
    if gap>.10:raise ValueError('Nikkei daily/10m mismatch')
    detail={'status':'OK','source':'Validated same-date Nikkei Yahoo cache','input_hashes':hashes,
        'upstream_validation_sha256':sha256_file(valpath),'intraday_status':'OK_CONTIGUOUS_WINDOW' if gaps else 'OK',
        'intraday_source_gaps':gaps,'intraday_active_window_gaps':[],
        'intraday_can_use':True,'intraday_analysis_window':window,'close_crosscheck_gap_pct':gap,
        'latest_session_10m_bars':int((bars.index.date==target).sum())}
    base={'monthly':resample_ohlcv(daily,'ME'),'weekly':resample_ohlcv(daily,'W-FRI'),'daily':daily,'intraday_10m':bars}
    item=export_frames('NIKKEI225','니케이225',base,detail,target,day,out,True);item['symbol']='^N225'
    return item,detail

def self_test():
    assert expected_session(datetime(2026,9,7,15,30,tzinfo=KST))==date(2026,9,4)
    assert expected_session(datetime(2026,9,8,8,tzinfo=KST))==date(2026,9,4)
    assert close_time(date(2026,11,27)).hour==13
    assert date(2021,12,31) in sessions(date(2021,12,30),date(2022,1,3))
    assert close_time(date(2026,3,6)).astimezone(KST).hour==6
    assert close_time(date(2026,3,9)).astimezone(KST).hour==5
    i=pd.date_range('2026-09-04 09:30','2026-09-04 16:00',freq='5min',tz=NY)
    f=pd.DataFrame({'open':100.,'high':101.,'low':99.,'close':100.,'volume':0.},index=i)
    bars,gaps=intraday_bars(f,date(2026,9,4));assert len(bars)==39 and not gaps and bars.index[-1].hour==15
    _,gaps=intraday_bars(f.drop(i[5]),date(2026,9,4));assert gaps[0]['missing_5m_count']==1
    days=pd.to_datetime(['2026-09-03','2026-09-04','2026-09-07','2026-09-08'])
    sample=pd.DataFrame({'close':[100,101,102,103]},index=days)
    joined=linked_history(sample,sample)
    assert (joined.us_date.dt.date<joined.kr_date.dt.date).all()
    assert joined.loc[joined.kr_date==pd.Timestamp('2026-09-07'),'us_date'].iloc[0]==pd.Timestamp('2026-09-04')
    ji=pd.date_range('2026-09-07 09:00','2026-09-07 11:30',freq='5min',tz='Asia/Tokyo').append(pd.date_range('2026-09-07 12:30','2026-09-07 15:30',freq='5min',tz='Asia/Tokyo'))
    jf=pd.DataFrame({'open':100.,'high':101.,'low':99.,'close':100.,'volume':0.},index=ji)
    jbars,jgaps=japan_10m(jf);assert len(jbars)==33 and not jgaps
    assert not any(time(11,30)<=t<time(12,30) for t in jbars.index.time)
    full=pd.concat([jf.set_axis(jf.index+pd.Timedelta(days=i)) for i in range(9)])
    broken=full.drop(full.index[5])
    active,recorded,audit=validated_japan_window(broken,date(2026,9,15))
    assert recorded and audit['gap_excluded_through']=='2026-09-07' and audit['filled_bars']==0
    assert active.index[0].date()==date(2026,9,8) and not japan_10m(broken[broken.index.date>date(2026,9,7)])[1]
    for bad in [full.drop(full.index[-5]),full.iloc[:74].drop(full.index[5])]:
        try:validated_japan_window(bad,bad.index[-1].date())
        except ValueError:pass
        else:raise AssertionError('Latest-day gap or insufficient suffix must fail closed')
    print('SELF_TEST_OK: holidays, DST, final-print folding, missing-bar detection, no future US close')

def run(day,root,domestic_source_root=None):
    target=datetime.strptime(day,'%Y%m%d').date();now=datetime.now(KST)
    if target>now.date():raise ValueError('Future Korean trade date not allowed')
    write_json(root/'validation_latest.json',{'trade_date':day,'status':'RUNNING','can_use_for_context':False})
    cutoff=min(datetime.combine(target,time(15,30),KST),now)
    us_day=expected_session(cutoff)
    out=root/day/now.strftime('%H%M%S');out.mkdir(parents=True,exist_ok=True)
    result={'schema_version':'1.0','trade_date':day,'generated_at':now.isoformat(),'cutoff_kst':cutoff.isoformat(),
        'source_session_date':str(us_day),'source_role':'DELAYED_SECONDARY_SUPPLEMENT_ONLY','indices':{},
        'limitations':['거래소 공식 가격 독립 검증 아님','미국 현물과 선물은 별도 상품','월·주 진행봉은 점수에서 제외',
        '나스닥·SOX 중복 요인을 독립 점수로 더하지 않음','정확한 코스피 상승 기여도는 직전 종목 비중이 없으면 산출하지 않음',
        '휴장으로 같은 미국 세션이 여러 한국 거래일에 연결될 수 있어 관측수와 고유 미국 세션수를 분리함. 상관·일치율은 검증된 예측 승률이 아님'],
        'calendar_policy':'NYSE standard holidays + known special closures; new unscheduled closures require review',
        'domestic_comparison':{},'contribution_analysis':{'status':'DATA_UNAVAILABLE','required':'동일 기준 직전 거래일 삼성전자·SK하이닉스 및 전체 KOSPI 구성 비중. 당일 비중이나 오래된 비중으로 대체 금지.'}}
    checks={};all_frames={}
    for key,instrument in INDICES.items():
        try:
            rawdaily,audit=fetch(instrument,'1d',us_day,out/'raw'/f'{key}_daily.json')
            daily=daily_by_local_date(rawdaily)
            missing=set(sessions(daily.index[0].date(),us_day))-set(daily.index.date)
            unexpected=set(daily.index.date)-set(sessions(daily.index[0].date(),us_day))
            if missing or unexpected:raise ValueError(f'Daily calendar mismatch missing={sorted(missing)[:10]} unexpected={sorted(unexpected)[:10]}')
            base={'monthly':resample_ohlcv(daily,'ME'),'weekly':resample_ohlcv(daily,'W-FRI'),'daily':daily}
            detail={'status':'OK','daily_audit':audit,'calendar_missing':0,'calendar_unexpected':0,'intraday_status':'UNAVAILABLE'}
            try:
                intra,ia=fetch(instrument,'5m',us_day,out/'raw'/f'{key}_5m.json')
                bars,gaps=intraday_bars(intra,us_day)
                close_gap=abs(float(intra.iloc[-1].close)/float(daily.iloc[-1].close)-1)*100
                if close_gap>.10:raise ValueError(f'Daily/intraday close mismatch {close_gap:.4f}%')
                detail.update(intraday_audit=ia,intraday_source_gaps=gaps,close_crosscheck_gap_pct=close_gap,
                    intraday_status='OK' if not gaps else 'SOURCE_GAP',intraday_can_use=not gaps)
                # Gapped intraday data retained but excluded from chart signal interpretation.
                base['intraday_10m']=bars
                intra.to_csv(out/f'{key}_5m.csv',index_label='timestamp')
            except Exception as e:detail.update(intraday_error=str(e),intraday_can_use=False)
            result['indices'][key]=export_frames(key,instrument.name,base,detail,us_day,day,out)
            result['indices'][key]['symbol']=instrument.symbol
            checks[key]=detail;all_frames[key]=daily
        except Exception as e:checks[key]={'status':'FAILED','error':str(e)}
    # Domestic data is read only; unavailable inputs are not silently substituted.
    domestic_root=(domestic_source_root or BASE/'output/index_multitimeframe')/day
    try:
        valid=json.loads((domestic_root/f'validation_{day}.json').read_text(encoding='utf-8-sig'))
        if valid.get('trade_date')!=day or not valid.get('can_use_for_decision'):raise ValueError('Domestic validation failed')
        for market in ['kospi','kosdaq']:
            df=pd.read_csv(domestic_root/'data'/f'{market}_daily_{day}.csv',index_col=0,parse_dates=True)
            df=df[df.index.date<=target]
            if df.index[-1].date()!=target:raise ValueError('Domestic target missing')
            ret=df.close.pct_change()*100
            result['domestic_comparison'][market]={'close':float(df.close.iloc[-1]),'return_pct':float(ret.iloc[-1]),
                'opening_gap_pct':float((df.open.iloc[-1]/df.close.iloc[-2]-1)*100),'open_to_close_pct':float((df.close.iloc[-1]/df.open.iloc[-1]-1)*100),'us_leading_relationships':{}}
            for key,daily in all_frames.items():
                linked=linked_history(daily,df);linked.to_csv(out/f'{key}_to_{market}_point_in_time.csv',index=False)
                stats={}
                for n in [20,60,120]:
                    t=linked.tail(n);stats[str(n)]={'observations':len(t),'distinct_us_sessions':t.us_date.nunique(),
                        'correlation':t.us_return.corr(t.kr_return),'direction_match_pct':float((np.sign(t.us_return)==np.sign(t.kr_return)).mean()*100)}
                result['domestic_comparison'][market]['us_leading_relationships'][key]=stats
    except Exception as e:result['domestic_comparison']={'status':'UNAVAILABLE','reason':str(e)}
    if len(all_frames)==3:
        returns={k:float(f.close.pct_change().iloc[-1]*100) for k,f in all_frames.items()}
        result['cross_index_context']={'returns_pct':returns,'sox_minus_nasdaq_pp':returns['SOX']-returns['NASDAQ'],
            'observation':'나스닥 하락·반도체 상승의 업종 차별화' if returns['NASDAQ']<0<returns['SOX'] else '미국 지수별 방향·상대강도 비교 필요',
            'interpretation_rule':'SOX 강세는 국내 반도체 확인 근거. 코스피 전체 상방 확정이나 수익률 인과 기여도로 사용하지 않음.'}
    try:
        result['indices']['NIKKEI225'],checks['NIKKEI225']=add_nikkei(day,out,domestic_source_root)
    except Exception as e:checks['NIKKEI225']={'status':'FAILED','error':str(e)}
    window=checks.get('NIKKEI225',{}).get('intraday_analysis_window')
    if window and window.get('gap_excluded_through'):
        result['limitations'].append(f"니케이 과거 원천 누락은 미복원. 10분 계산은 {window['start']} ~ {window['end']} 완전 연속 구간만 사용. 누락일과 이전 자료는 지표에서 제외하며 값을 채우지 않음.")
    ready=len(all_frames)==3 and checks['NIKKEI225']['status']=='OK' and all(x.get('intraday_can_use') for x in checks.values())
    result.update(status='OK' if ready else 'PARTIAL',can_use_for_context=ready)
    write_json(out/'analysis.json',result)
    validation={'trade_date':day,'source_session_date':str(us_day),'status':result['status'],'can_use_for_context':ready,
        'checks':checks,'analysis_path':str(out/'analysis.json'),'analysis_sha256':sha256_file(out/'analysis.json'),
        'script_sha256':sha256_file(Path(__file__)),'shared_module_sha256':sha256_file(BASE/'kospi_nikkei_mtf_daily.py'),
        'artifacts':[{'path':str(p),'sha256':sha256_file(p)} for p in sorted(out.rglob('*')) if p.is_file()]}
    lines=[f'# 미국 지수 보조 분석 · 한국 {day} / 미국 완료장 {us_day}','',
        'Yahoo 지연 보조 원천이며 공식 가격 독립 검증은 아닙니다.','']
    for key,item in result['indices'].items():
        d=item['timeframes']['daily'];lines += [f"## {item['name']}",'',f"종가 {d['ohlc']['close']} · 1/5/20일 {d['returns_pct']} · 일봉 {d['state']} · RSI {d['rsi14']}",'',f"이평 {d['moving_averages']}",'',f"가격 비교 {d['levels']}",'']
    lines += ['## 국내 연결','',json.dumps(result['domestic_comparison'],ensure_ascii=False,indent=2),'','## 한계','',*result['limitations']]
    (out/'analysis.md').write_text('\n'.join(lines),encoding='utf-8')
    validation['artifacts']=[{'path':str(p),'sha256':sha256_file(p)} for p in sorted(out.rglob('*')) if p.is_file() and p.name!='validation.json']
    write_json(out/'validation.json',validation)
    write_json(root/'validation_latest.json',validation);write_json(root/'latest_attempt.json',result)
    if ready:write_json(root/'latest.json',result)
    print(json.dumps({'status':result['status'],'trade_date':day,'us_session':str(us_day),'output':str(out),'validation':checks},ensure_ascii=False))
    return 0 if ready else 2

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--trade-date');parser.add_argument('--self-test',action='store_true');parser.add_argument('--output-root',type=Path,default=BASE/'output/us_index_multitimeframe');parser.add_argument('--domestic-root',type=Path,help='Validated domestic source root for isolated recovery; defaults to the operational cache');args=parser.parse_args()
    plt.rcParams['font.family']=['Malgun Gothic','DejaVu Sans'];plt.rcParams['axes.unicode_minus']=False
    if args.self_test:self_test()
    else:
        if not args.trade_date:parser.error('--trade-date required')
        raise SystemExit(run(args.trade_date,args.output_root,args.domestic_root))
