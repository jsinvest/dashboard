# 미국 지수 보조 분석 · 한국 20261110 / 미국 완료장 2026-11-09

Yahoo 지연 보조 원천이며 공식 가격 독립 검증은 아닙니다.

## 나스닥종합

종가 25253.141 · 1/5/20일 {'1': 2.741, '5': 0.353, '20': -7.314, '60': -5.522} · 일봉 하락 · RSI 42.448

이평 {'sma5': 25051.218, 'sma10': 25506.978, 'sma20': 25975.612, 'sma60': 26407.675, 'sma120': 26224.62, 'sma240': 24822.115}

가격 비교 {'previous_20_high': 27376.66, 'previous_20_low': 24262.141, 'previous_60_high': 27722.75, 'previous_60_low': 24262.141}

## 필라델피아 반도체

종가 10033.93 · 1/5/20일 {'1': 6.855, '5': -2.85, '20': -18.002, '60': -19.192} · 일봉 하락 · RSI 39.839

이평 {'sma5': 9860.874, 'sma10': 10500.62, 'sma20': 10915.924, 'sma60': 11686.062, 'sma120': 12161.483, 'sma240': 10258.999}

가격 비교 {'previous_20_high': 12378.31, 'previous_20_low': 8997.39, 'previous_60_high': 13349.96, 'previous_60_low': 8997.39}

## 다우 산업평균

종가 52389.75 · 1/5/20일 {'1': 2.153, '5': 0.781, '20': 1.04, '60': -2.499} · 일봉 중립-하락 · RSI 52.458

이평 {'sma5': 52068.276, 'sma10': 52129.09, 'sma20': 52176.265, 'sma60': 52265.36, 'sma120': 52165.377, 'sma240': 50320.016}

가격 비교 {'previous_20_high': 53710.609, 'previous_20_low': 50992.609, 'previous_60_high': 53890.84, 'previous_60_low': 50546.539}

## 니케이225

종가 60459.578 · 1/5/20일 {'1': 2.865, '5': -4.157, '20': -12.417, '60': -9.722} · 일봉 하락 · RSI 39.787

이평 {'sma5': 59987.275, 'sma10': 61819.037, 'sma20': 63243.322, 'sma60': 65367.868, 'sma120': 65944.407, 'sma240': 60088.832}

가격 비교 {'previous_20_high': 69143.453, 'previous_20_low': 56745.809, 'previous_60_high': 70798.617, 'previous_60_low': 56745.809}

## 국내 연결

{
  "kospi": {
    "close": 5239.13,
    "return_pct": 4.389053269175203,
    "opening_gap_pct": 4.55024557418533,
    "open_to_close_pct": -0.15417687842324002,
    "us_leading_relationships": {
      "NASDAQ": {
        "20": {
          "observations": 20,
          "distinct_us_sessions": 20,
          "correlation": 0.3466216048596673,
          "direction_match_pct": 55.00000000000001
        },
        "60": {
          "observations": 60,
          "distinct_us_sessions": 59,
          "correlation": 0.277646435069112,
          "direction_match_pct": 58.333333333333336
        },
        "120": {
          "observations": 120,
          "distinct_us_sessions": 117,
          "correlation": 0.3556462643055971,
          "direction_match_pct": 62.5
        }
      },
      "SOX": {
        "20": {
          "observations": 20,
          "distinct_us_sessions": 20,
          "correlation": 0.45353225304003525,
          "direction_match_pct": 50.0
        },
        "60": {
          "observations": 60,
          "distinct_us_sessions": 59,
          "correlation": 0.42072374300969895,
          "direction_match_pct": 60.0
        },
        "120": {
          "observations": 120,
          "distinct_us_sessions": 117,
          "correlation": 0.4149657792877768,
          "direction_match_pct": 63.33333333333333
        }
      },
      "DOW": {
        "20": {
          "observations": 20,
          "distinct_us_sessions": 20,
          "correlation": 0.1989831660997515,
          "direction_match_pct": 65.0
        },
        "60": {
          "observations": 60,
          "distinct_us_sessions": 59,
          "correlation": 0.039438706951478504,
          "direction_match_pct": 55.00000000000001
        },
        "120": {
          "observations": 120,
          "distinct_us_sessions": 117,
          "correlation": 0.1308813113216044,
          "direction_match_pct": 54.166666666666664
        }
      }
    }
  },
  "kosdaq": {
    "close": 667.61,
    "return_pct": 4.482213562452064,
    "opening_gap_pct": 3.561982565691668,
    "open_to_close_pct": 0.8885799344143352,
    "us_leading_relationships": {
      "NASDAQ": {
        "20": {
          "observations": 20,
          "distinct_us_sessions": 20,
          "correlation": 0.35418435593713354,
          "direction_match_pct": 60.0
        },
        "60": {
          "observations": 60,
          "distinct_us_sessions": 59,
          "correlation": 0.3294848245595262,
          "direction_match_pct": 56.666666666666664
        },
        "120": {
          "observations": 120,
          "distinct_us_sessions": 117,
          "correlation": 0.38026489827034254,
          "direction_match_pct": 58.333333333333336
        }
      },
      "SOX": {
        "20": {
          "observations": 20,
          "distinct_us_sessions": 20,
          "correlation": 0.44420059061085654,
          "direction_match_pct": 55.00000000000001
        },
        "60": {
          "observations": 60,
          "distinct_us_sessions": 59,
          "correlation": 0.32630222471173403,
          "direction_match_pct": 58.333333333333336
        },
        "120": {
          "observations": 120,
          "distinct_us_sessions": 117,
          "correlation": 0.34441113298947273,
          "direction_match_pct": 59.166666666666664
        }
      },
      "DOW": {
        "20": {
          "observations": 20,
          "distinct_us_sessions": 20,
          "correlation": 0.223451232327431,
          "direction_match_pct": 60.0
        },
        "60": {
          "observations": 60,
          "distinct_us_sessions": 59,
          "correlation": 0.13126780307461094,
          "direction_match_pct": 50.0
        },
        "120": {
          "observations": 120,
          "distinct_us_sessions": 117,
          "correlation": 0.14973934300938638,
          "direction_match_pct": 50.0
        }
      }
    }
  }
}

## 한계

거래소 공식 가격 독립 검증 아님
미국 현물과 선물은 별도 상품
월·주 진행봉은 점수에서 제외
나스닥·SOX 중복 요인을 독립 점수로 더하지 않음
정확한 코스피 상승 기여도는 직전 종목 비중이 없으면 산출하지 않음
휴장으로 같은 미국 세션이 여러 한국 거래일에 연결될 수 있어 관측수와 고유 미국 세션수를 분리함. 상관·일치율은 검증된 예측 승률이 아님
니케이 과거 원천 누락은 미복원. 10분 계산은 2026-10-16T09:00:00+09:00 ~ 2026-11-10T15:20:00+09:00 완전 연속 구간만 사용. 누락일과 이전 자료는 지표에서 제외하며 값을 채우지 않음.