# 미국 지수 보조 분석 · 한국 20261111 / 미국 완료장 2026-11-10

Yahoo 지연 보조 원천이며 공식 가격 독립 검증은 아닙니다.

## 나스닥종합

종가 25065.869 · 1/5/20일 {'1': -0.742, '5': -1.207, '20': -7.861, '60': -5.926} · 일봉 하락 · RSI 40.86

이평 {'sma5': 24989.99, 'sma10': 25365.784, 'sma20': 25868.686, 'sma60': 26381.357, 'sma120': 26214.583, 'sma240': 24830.616}

가격 비교 {'previous_20_high': 27277.881, 'previous_20_low': 24262.141, 'previous_60_high': 27722.75, 'previous_60_low': 24262.141}

## 필라델피아 반도체

종가 9998.33 · 1/5/20일 {'1': -0.355, '5': -5.68, '20': -18.105, '60': -20.78} · 일봉 하락 · RSI 39.556

이평 {'sma5': 9740.46, 'sma10': 10352.203, 'sma20': 10805.401, 'sma60': 11642.35, 'sma120': 12146.358, 'sma240': 10272.683}

가격 비교 {'previous_20_high': 12217.21, 'previous_20_low': 8997.39, 'previous_60_high': 13349.96, 'previous_60_low': 8997.39}

## 다우 산업평균

종가 52231.891 · 1/5/20일 {'1': -0.301, '5': 0.86, '20': 1.087, '60': -2.297} · 일봉 중립-하락 · RSI 51.178

이평 {'sma5': 52157.31, 'sma10': 52114.522, 'sma20': 52204.354, 'sma60': 52244.896, 'sma120': 52183.898, 'sma240': 50341.347}

가격 비교 {'previous_20_high': 53710.609, 'previous_20_low': 50992.609, 'previous_60_high': 53819.648, 'previous_60_low': 50546.539}

## 니케이225

종가 61248.59 · 1/5/20일 {'1': 1.305, '5': -1.512, '20': -9.633, '60': -9.294} · 일봉 하락 · RSI 42.886

이평 {'sma5': 59799.267, 'sma10': 61617.059, 'sma20': 62916.875, 'sma60': 65263.277, 'sma120': 65948.012, 'sma240': 60130.36}

가격 비교 {'previous_20_high': 68710.992, 'previous_20_low': 56745.809, 'previous_60_high': 70798.617, 'previous_60_low': 56745.809}

## 국내 연결

{
  "kospi": {
    "close": 5375.36,
    "return_pct": 2.6002408796880205,
    "opening_gap_pct": -0.5615436150658626,
    "open_to_close_pct": 3.1796395576721093,
    "us_leading_relationships": {
      "NASDAQ": {
        "20": {
          "observations": 20,
          "distinct_us_sessions": 20,
          "correlation": 0.3315620456231678,
          "direction_match_pct": 50.0
        },
        "60": {
          "observations": 60,
          "distinct_us_sessions": 59,
          "correlation": 0.2801691812413446,
          "direction_match_pct": 58.333333333333336
        },
        "120": {
          "observations": 120,
          "distinct_us_sessions": 117,
          "correlation": 0.3629154664554949,
          "direction_match_pct": 62.5
        }
      },
      "SOX": {
        "20": {
          "observations": 20,
          "distinct_us_sessions": 20,
          "correlation": 0.45023424297947323,
          "direction_match_pct": 45.0
        },
        "60": {
          "observations": 60,
          "distinct_us_sessions": 59,
          "correlation": 0.41576501847045716,
          "direction_match_pct": 58.333333333333336
        },
        "120": {
          "observations": 120,
          "distinct_us_sessions": 117,
          "correlation": 0.41886337133186485,
          "direction_match_pct": 63.33333333333333
        }
      },
      "DOW": {
        "20": {
          "observations": 20,
          "distinct_us_sessions": 20,
          "correlation": 0.18376215443025637,
          "direction_match_pct": 60.0
        },
        "60": {
          "observations": 60,
          "distinct_us_sessions": 59,
          "correlation": 0.04247783857519255,
          "direction_match_pct": 55.00000000000001
        },
        "120": {
          "observations": 120,
          "distinct_us_sessions": 117,
          "correlation": 0.13918980435556558,
          "direction_match_pct": 54.166666666666664
        }
      }
    }
  },
  "kosdaq": {
    "close": 705.1,
    "return_pct": 5.615553991102584,
    "opening_gap_pct": 0.13031560342116055,
    "open_to_close_pct": 5.478099569171846,
    "us_leading_relationships": {
      "NASDAQ": {
        "20": {
          "observations": 20,
          "distinct_us_sessions": 20,
          "correlation": 0.3098769315719272,
          "direction_match_pct": 55.00000000000001
        },
        "60": {
          "observations": 60,
          "distinct_us_sessions": 59,
          "correlation": 0.29674752752049754,
          "direction_match_pct": 56.666666666666664
        },
        "120": {
          "observations": 120,
          "distinct_us_sessions": 117,
          "correlation": 0.37846685575176786,
          "direction_match_pct": 58.333333333333336
        }
      },
      "SOX": {
        "20": {
          "observations": 20,
          "distinct_us_sessions": 20,
          "correlation": 0.4210677600648687,
          "direction_match_pct": 50.0
        },
        "60": {
          "observations": 60,
          "distinct_us_sessions": 59,
          "correlation": 0.3094928049775431,
          "direction_match_pct": 56.666666666666664
        },
        "120": {
          "observations": 120,
          "distinct_us_sessions": 117,
          "correlation": 0.34325322317952384,
          "direction_match_pct": 59.166666666666664
        }
      },
      "DOW": {
        "20": {
          "observations": 20,
          "distinct_us_sessions": 20,
          "correlation": 0.17767508788455036,
          "direction_match_pct": 55.00000000000001
        },
        "60": {
          "observations": 60,
          "distinct_us_sessions": 59,
          "correlation": 0.11606893788766355,
          "direction_match_pct": 50.0
        },
        "120": {
          "observations": 120,
          "distinct_us_sessions": 117,
          "correlation": 0.1525814837195467,
          "direction_match_pct": 50.0
        }
      }
    }
  }
}

## 한계

거래소 공식 가격 독립 검증 아님
미국 현물과 선물은 별도 상품
월·주 진행봉은 점수에서 제외
나스닥·SOX 중복 요인을 독립 점수로 더하지 않음
정확한 코스피 상승 기여도는 직전 종목 비중이 없으면 산출하지 않음
휴장으로 같은 미국 세션이 여러 한국 거래일에 연결될 수 있어 관측수와 고유 미국 세션수를 분리함. 상관·일치율은 검증된 예측 승률이 아님
니케이 과거 원천 누락은 미복원. 10분 계산은 2026-10-16T09:00:00+09:00 ~ 2026-11-11T15:20:00+09:00 완전 연속 구간만 사용. 누락일과 이전 자료는 지표에서 제외하며 값을 채우지 않음.